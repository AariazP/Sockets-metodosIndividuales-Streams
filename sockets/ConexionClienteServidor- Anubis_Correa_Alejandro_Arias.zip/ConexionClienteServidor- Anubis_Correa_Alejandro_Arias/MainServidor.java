package sockets.ejemploEnviaryRecibirObjetos;

public class MainServidor {

	public static void main(String[] args) {
		AppServidor appServidor = new AppServidor();
		appServidor.iniciarServidor();
	}

}
